#!/bin/bash
echo Linux
