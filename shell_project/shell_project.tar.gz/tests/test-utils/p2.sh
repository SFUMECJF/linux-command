#!/bin/bash
sleep 3
cd tests/test-utils/p2a-test
ls test2

